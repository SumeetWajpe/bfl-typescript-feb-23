function GetData() {
  return axios.get("https://jsonplaceholder.typicode.com/postsss");
}
