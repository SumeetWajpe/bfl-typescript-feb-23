import axios from "axios";

type Post = {
  id: number;
  userId: number;
  title: string;
  body: string;
};

type PostsResponse = {
  data: Post[];
};

async function LoadPosts() {
  let { data } = await axios.get<PostsResponse>(
    "https://jsonplaceholder.typicode.com/posts",
  );
  console.log(data);
}

LoadPosts();
