import * as MathModule from "./Math";

console.log(MathModule.Add(20, 30));
// import Division, { Add, Product as Multiplication } from "./Math";

// console.log(Add(30, 40));
// console.log(Multiplication(30, 40));
