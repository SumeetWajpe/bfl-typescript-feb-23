export function Add(x: number, y: number): number {
  return x + y;
}

export function Product(x: number, y: number): number {
  return x * y;
}

export default function Divide(x: number, y: number) {
  return x / y;
}
