// Enum
var Designation;
(function (Designation) {
    Designation[Designation["Trainer"] = 100] = "Trainer";
    Designation[Designation["Developer"] = 101] = "Developer";
    Designation[Designation["Architect"] = 102] = "Architect";
    Designation[Designation["Tester"] = 103] = "Tester";
})(Designation || (Designation = {}));
var myDesignation;
myDesignation = Designation.Developer;
// console.log(myDesignation); // 101
console.log(Designation[myDesignation]); // Developer
// Interfaces
// interface IPerson {
//   fname: string;
//   sport?: string; //optional
//   getdetails: () => void;
// }
// let person: IPerson = {
//   fname: "Rafael",
//   getdetails: function () {
//     console.log(this.fname);
//   },
// };
// person.getdetails();
// let people: IPerson[] = [
//   {
//     fname: "Novak",
//     getdetails: function () {
//       console.log(this.fname);
//     },
//   },
//   {
//     fname: "Andy",
//     getdetails: function () {
//       console.log(this.fname);
//     },
//   },
// ];
// Objects
// 1. Object Literal Syntax
var company = { name: "Microsoft", city: "Redmond" };
var Emp = /** @class */ (function () {
    function Emp() {
    }
    return Emp;
}());
var EnhancedCar = /** @class */ (function () {
    function EnhancedCar(id, name, speed, carMake) {
        if (id === void 0) { id = 0; }
        if (name === void 0) { name = "BMW"; }
        if (speed === void 0) { speed = 200; }
        if (carMake === void 0) { carMake = "1983"; }
        this.id = id;
        this.name = name;
        this.speed = speed;
        this.carMake = carMake;
    }
    return EnhancedCar;
}());
var carObj = new EnhancedCar();
// String Templates
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "AUDI"; }
        if (speed === void 0) { speed = 200; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.accelerate = function () {
        //return "The car " + this.name + " is running at " + this.speed + " kmph !";
        return "The car ".concat(this.name, " is running at ").concat(this.speed, " kmph !");
    };
    return Car;
}());
var longString = "First Line\nSecond Line\n  Last Line !";
console.log(longString);
