// let cars: string[] = ["BMW", "AUDI", "MERC"];
// for (const car of cars) {
//   console.log(car);
// }
// let person = { name: "sachin", runsScored: 150000 };
// for (const prop of person) {
//   console.log(prop);
// }
// Use Iterator
let cars = ["BMW", "AUDI", "MERC"];
let iterator = cars[Symbol.iterator]();
// console.log(iterator.next());
// // after 1000 lines of code
// console.log(iterator.next());
// console.log(iterator.next());
// console.log(iterator.next());
let person = {
    name: "sachin",
    runsScored: 15000,
    city: "Mumbai",
    country: "India",
    [Symbol.iterator]() {
        let values = Object.values(this);
        let index = 0;
        return {
            next() {
                if (index < values.length) {
                    let value = values[index];
                    index++;
                    return {
                        value: value,
                        done: false,
                    };
                }
                else {
                    return {
                        value: undefined,
                        done: true,
                    };
                }
            },
        };
    },
};
// for (const prop of person) {
//   console.log(prop);
// }
// let itr = person[Symbol.iterator]();
// console.log(itr.next());
function* MyGenerator() {
    console.log("Started !");
    let returnedValue = yield 10;
    console.log(returnedValue);
    console.log("Ended");
}
let itr = MyGenerator();
console.log(itr.next());
console.log("Back to main prog");
console.log(itr.next(20));
