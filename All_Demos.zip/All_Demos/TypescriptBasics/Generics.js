function Swap(x, y) {
    var temp;
    temp = x;
    x = y;
    y = temp;
    console.log(x, y);
}
Swap(10, 20);
Swap("Hello", "World");
var Point = /** @class */ (function () {
    function Point(x, y) {
        this.x = x;
        this.y = y;
    }
    return Point;
}());
var pointObj = new Point(20, 30);
var Emp = /** @class */ (function () {
    function Emp() {
    }
    return Emp;
}());
var Person = /** @class */ (function () {
    function Person() {
    }
    return Person;
}());
var CabServices = /** @class */ (function () {
    function CabServices() {
    }
    return CabServices;
}());
var cabServicesObj = new CabServices();
var cabServicesObjForPerson = new CabServices();
// let cabServicesObjForString: CabServices<string> = new CabServices<string>(); // Error
