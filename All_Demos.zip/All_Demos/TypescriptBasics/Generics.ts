function Swap<T>(x: T, y: T) {
  let temp: T;
  temp = x;
  x = y;
  y = temp;
  console.log(x, y);
}
Swap<number>(10, 20);
Swap<string>("Hello", "World");

class Point<T> {
  x: T;
  y: T;
  constructor(x: T, y: T) {
    this.x = x;
    this.y = y;
  }
}

let pointObj: Point<number> = new Point<number>(20, 30);

interface IPerson {
  name: string;
  age: number;
}
class Emp implements IPerson {
  id: number;
  salary: number;
  name: string;
  age: number;
}
class Person implements IPerson {
  name: string;
  age: number;
}
class CabServices<T extends IPerson> {
  cabRoute: string;
  travellers: T[];
}
let cabServicesObj: CabServices<Emp> = new CabServices<Emp>();
let cabServicesObjForPerson: CabServices<Person> = new CabServices<Person>();
// let cabServicesObjForString: CabServices<string> = new CabServices<string>(); // Error
