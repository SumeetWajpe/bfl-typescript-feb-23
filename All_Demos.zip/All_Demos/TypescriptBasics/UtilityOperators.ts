// Spread Operator
// With Arrays

// let cars: string[] = ["bmw", "audi", "merc"];
// let moreCars: string[] = ["tata", "maruti"];
// let allCars: string[] = [...cars, ...moreCars, "hyundai"];
// console.log(allCars);

// with Objects
// let person = { name: "Djokivic", country: "Serbia" };
// let player = {
//   ...person,
//   sport: "Tennis",
//   isFirstSeeded: true,
//   country: "SRB",
// };
// console.log(player);

// Destructuring- with Objects & Arrays
// with Arays

//let cars: string[] = ["bmw", "audi", "merc"];
// let firstCar: string, secondCar: string;
// firstCar = cars[0];
// secondCar = cars[1];
// OR

// let [firstCar, , , secondCar = "GM"] = cars;
// console.log(secondCar);

// With Objects
// let person = {
//   fname: "Djokivic",
//   country: "Serbia",
//   sport: "Tennis",
//   isFirstSeeded: true,
// };
// let fname: string = person.fname;
// let country: string = person.country;
// OR
// let { country, fname,  } = person;

// ES8- Rest Properties
// let { country, fname, ...restProperties } = person;
// console.log(restProperties);

// Usage
let person = {
  fname: "Djokivic",
  country: "Serbia",
  sport: "Tennis",
  isFirstSeeded: true,
};

function PrintPerson({ fname, country }) {
  console.log(fname + " lives in " + country);
}

PrintPerson(person);

console.log(person);
