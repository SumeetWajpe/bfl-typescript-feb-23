var PI = 3.14;
var Square = function (x) {
    return x * x;
};
