const PI = 3.14;

let Square = (x: number) => {
  return x * x;
};
