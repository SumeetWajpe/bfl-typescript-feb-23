export const Add = (x, y) => {
  return x + y;
};

function Product(x, y) {
  return x * y;
}

export class Point {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  printPoint() {
    console.log(`[X=${this.x},Y=${this.y}]`);
  }
}
