// Enum

enum Designation {
  Trainer = 100,
  Developer,
  Architect,
  Tester,
}

let myDesignation: Designation;
myDesignation = Designation.Developer;
// console.log(myDesignation); // 101
console.log(Designation[myDesignation]); // Developer

// Interfaces

// interface IPerson {
//   fname: string;
//   sport?: string; //optional
//   getdetails: () => void;
// }

// let person: IPerson = {
//   fname: "Rafael",
//   getdetails: function () {
//     console.log(this.fname);
//   },
// };
// person.getdetails();

// let people: IPerson[] = [
//   {
//     fname: "Novak",
//     getdetails: function () {
//       console.log(this.fname);
//     },
//   },
//   {
//     fname: "Andy",
//     getdetails: function () {
//       console.log(this.fname);
//     },
//   },
// ];

// Objects

// 1. Object Literal Syntax
let company = { name: "Microsoft", city: "Redmond" };
// company.country = "USA"; // Error

// 2. Using Object Object

// let point = new Object();
// point.x = 100;

// 3. Using Constrcutor

// function Car() {
//   this.name = "BMW";
//   this.speed = 200;
// }

// let carObj = new Car();

// 4. Classes

// class Car {
//   // private id:number;
//   public name: string;
//   speed: number;
//   protected carMake: string;

//   constructor(name: string = "AUDI", speed: number = 200) {
//     this.name = name;
//     this.speed = speed;
//   }
//   accelerate(): string {
//     return "The car " + this.name + " is running at " + this.speed + " kmph !";
//   }
// }
// // let carObj = new Car("BMW", 300);
// // console.log(carObj.accelerate());

// class BatmanCar extends Car {
//   isArmed: boolean;
//   constructor(name: string, speed: number, isArmed: boolean) {
//     super(name, speed);
//     this.isArmed = isArmed;
//   }
// }

// var carObj = new Car();

// interface IPerson {
//   name: string;
//   age: number;
// }

// interface IEmployee {
//   id: number;
//   salary: number;
// }

// class Employee implements IEmployee, IPerson {
//   id: number;
//   salary: number;
//   name: string;
//   age: number;
// }

// OR

interface IPerson {
  name: string;
  age: number;
}

interface IEmployee extends IPerson {
  id: number;
  salary: number;
}

class Emp implements IEmployee {
  id: number;
  salary: number;
  name: string;
  age: number;
}

class EnhancedCar {
  constructor(
    private id: number = 0,
    public name: string = "BMW",
    public speed: number = 200,
    protected carMake: string = "1983",
  ) {}
}

let carObj = new EnhancedCar();

// String Templates

class Car {
  // private id:number;
  public name: string;
  speed: number;
  protected carMake: string;

  constructor(name: string = "AUDI", speed: number = 200) {
    this.name = name;
    this.speed = speed;
  }
  accelerate(): string {
    //return "The car " + this.name + " is running at " + this.speed + " kmph !";
    return `The car ${this.name} is running at ${this.speed} kmph !`;
  }
}

let longString = `First Line
Second Line
  Last Line !`;
console.log(longString);
