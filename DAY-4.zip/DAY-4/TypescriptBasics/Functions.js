// function Add(x: number, y: number): number | string {
//   if (x == 0) {
//     return "x should not be zero !";
//   }
//   return x + y;
// }
// let result: number | string = Add(20, 30);
// console.log("The addition is : " + result);
// var Add = function (x: number, y: number): number {
//   return x + y;
// };
// console.log("The addition is : " + Add(20, 20));
// var cars: string[] = ["BMW", "AUDI", "MERC"];
// cars.forEach((car: string) => console.log(car));
// function Square(x: number): number {
//   return x * x;
// }
// let Square = (x: number): number => x * x;
// let result: number = Square(10);
// Optional Parameters
// function PrintBook(author?: string, title?: string, publication?: string) {
//   author = author || "Unknown";
//   console.log(author, title, publication);
// }
// PrintBook();
// Default Parameters
// function PrintBook(
//   author: string = "Unknown",
//   title: string,
//   publication: string,
// ) {
//   console.log(author, title, publication);
// }
// PrintBook(undefined, "XYZ", "PQR");
// Rest Parameters
// 1. Rest parameters cannnot be default | optional
//2. Ca not have multiple rest parameters
function PrintBook(author) {
    var titles = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        titles[_i - 1] = arguments[_i];
    }
    console.log(author, titles);
}
PrintBook("Dr. APJ Abdul Kalam", "India 2020", "Wings Of Fire");
PrintBook("Sachin Tendulkar", "Playing It My Way");
PrintBook("Sumeet Wajpe");
