//var x = 10; // Type Inferencing
// x = "Hello";
//console.log(typeof x);

// var x: number; // Type annotation
// x = 100;
// x = "Hello";

// var x; // x is implicitly typed - any
// x = 100;
// x = true;
// x = { name: "XYZ" };

// var b:boolean;
// var s:string;
// var o:object;

var x: number | string;
x = 100;
x = "Hello";

var arr: number[] = [10, 20, 30, 40];
// Or - Generics
// var anotherArray: Array<number> = new Array<number>(10, 20, 30);
// for (var n of anotherArray) {
//   console.log(n);
// }

// if (true) {
//   let x: number = 10;
//   if (true) {
//     let x: number = 100;
//     console.log(x);
//   }
//   console.log(x);
// }

// Variable Hoisting

let n;
n = 100;
console.log(n);

// const PI: number; // Error
// PI = 3.14;

const PI = 3.14;
// PI = 3.14564; // Error 
