// Enum
var Designation;
(function (Designation) {
    Designation[Designation["Trainer"] = 100] = "Trainer";
    Designation[Designation["Developer"] = 101] = "Developer";
    Designation[Designation["Architect"] = 102] = "Architect";
    Designation[Designation["Tester"] = 103] = "Tester";
})(Designation || (Designation = {}));
var myDesignation;
myDesignation = Designation.Developer;
// console.log(myDesignation); // 101
console.log(Designation[myDesignation]); // Developer
var person = {
    fname: "Rafael",
    getdetails: function () {
        console.log(this.fname);
    }
};
person.getdetails();
var people = [
    {
        fname: "Novak",
        getdetails: function () {
            console.log(this.fname);
        }
    },
    {
        fname: "Andy",
        getdetails: function () {
            console.log(this.fname);
        }
    },
];
