// Enum

enum Designation {
  Trainer = 100,
  Developer,
  Architect,
  Tester,
}

let myDesignation: Designation;
myDesignation = Designation.Developer;
// console.log(myDesignation); // 101
console.log(Designation[myDesignation]); // Developer

// Interfaces

interface IPerson {
  fname: string;
  sport?: string; //optional
  getdetails: () => void;
}

let person: IPerson = {
  fname: "Rafael",
  getdetails: function () {
    console.log(this.fname);
  },
};
person.getdetails();

let people: IPerson[] = [
  {
    fname: "Novak",
    getdetails: function () {
      console.log(this.fname);
    },
  },
  {
    fname: "Andy",
    getdetails: function () {
      console.log(this.fname);
    },
  },
];
